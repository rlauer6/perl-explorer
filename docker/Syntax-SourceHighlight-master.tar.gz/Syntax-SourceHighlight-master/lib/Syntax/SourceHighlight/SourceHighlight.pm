package Syntax::SourceHighlight::SourceHighlight;

use 5.010;
use strict;
use warnings;
use parent 'Syntax::SourceHighlight';

1;
